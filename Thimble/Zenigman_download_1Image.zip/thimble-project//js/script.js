"use strict"

;(function () {
  document.body.onmouseup = treatClick

  function treatClick(event) {
    let href = "00.html"
    window.location.href = href
  }
})()