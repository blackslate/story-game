document.body.onmouseup = function() {
  document.body.classList.add("clicked");
}