document.body.onmouseup = function() {
//  document.body.classList.add("clicked");
  window.location.href = "page_001.html";
}